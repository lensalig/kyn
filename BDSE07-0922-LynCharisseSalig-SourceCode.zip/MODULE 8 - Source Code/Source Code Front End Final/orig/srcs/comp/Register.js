import React, { Component } from 'react';
import axios from 'axios';

class Register extends Component {
  constructor(props) {
    super(props);
    this.state = {
      CarId: '',

      fullname: '',
      number: '',
      email: '',
      password: ''
    };
  }

  idChange = (event) => {
    this.setState({
      CarId: event.target.value
    });
  };

  fullnameChange = (event) => {
    this.setState({
      fullname: event.target.value
    });
  };

  numberChange = (event) => {
    this.setState({
      number: event.target.value
    });
  };

 emailChange = (event) => {
    this.setState({
      email: event.target.value
    });
  };

  passwordChange = (event) => {
    this.setState({
      password: event.target.value
    });
  };

  addAccount = (event) => {
    event.preventDefault();
    
    alert("Successfully saved! "+ this.state.fullname+" "+this.state.number+" "+this.state.email+" "+this.state.password);
 
    axios
      .post('/Register', this.state)
      .then((res) => {
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    return (

      <div>
      <div>
        <main className="main">
          <div className="containerreg">
            <section className="wrapperreg">
              <div className="heading">
                <h1 className="text text-large">Register</h1>
                <p className="text text-normal">
                  Already have an account?{' '}
                  <span>
                    <a href="/Login" className="text-links">
                      Login
                    </a>
                  </span>
                </p>
              </div>
              <form name="signin" onSubmit={this.addAccount} className="form">

              <div className="input-control">
                  <input
                    type="fullname"
                    required
                    name="fullname"
                    id="fullname"
                    className="input-field"
                    placeholder="Full Name"
                    value={this.state.fullname}
                    onChange={this.fullnameChange}
                  />
                </div>

                <div className="input-control">
                  <input
                    type="number"
                    required
                    name="number"
                    id="number"
                    className="input-field"
                    value={this.state.number}
                    onChange={this.numberChange}
                    placeholder="Contact Number"  maxlength="10" pattern="\d{10}" title="Please enter exactly 10 digits" 
                  />
                </div>

                <div className="input-control">
                  <input
                    type="email"
                    required
                    name="email"
                    id="email"
                    className="input-field"
                    placeholder="Email Address"
                    value={this.state.email}
                    onChange={this.emailChange}
                  />
                  </div>
                  <div className="input-control">
                    <label htmlFor="password" className="input-label" hidden required>
                    Password
                    </label>
                    <input
                      type="password"
                      required
                      name="password"
                      id="password"
                      className="input-field"
                      placeholder="Password"
                      value={this.state.password}
                      onChange={this.passwordChange}
                    />
                  </div>
                <div className="input-controlreg">
                  <input type="submit" name="submit" className="input-submitreg" value="REGISTER" />
                </div>
              </form>
              <div className="striped">
                <span className="striped-line"></span>
                <span className="striped-text">Or</span>
                <span className="striped-line"></span>
              </div>

              <div className="method">
                <div className="method-control">
                  <a href="#" className="method-action">
                    <img src="https://i.imgur.com/vDIE7nV.png" alt="Facebook Logo" />
                    <span>Sign up with Facebook</span>
                  </a>
                </div>
                <div className="method-control">
                  <a href="#" className="method-action">
                    <img src="https://i.imgur.com/AA7tajB.png" alt="Google Logo" />
                    <span>Sign up with Google</span>
                  </a>
                </div>
              </div>
            </section>
          </div>
        </main>

      </div>


</div>

    );
  }
}
export default Register;


