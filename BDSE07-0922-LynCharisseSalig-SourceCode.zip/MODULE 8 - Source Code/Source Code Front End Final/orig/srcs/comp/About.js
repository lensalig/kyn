import React, { Component } from 'react';
import axios from 'axios';

class About extends Component {

  render() {
    return (

<div class="pagediv">

      <header1/>




<title>W3.CSS Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1"/>


<div className="w3-container" style={{ backgroundColor: '#222', paddingBottom: '40px', color: 'white', padding: '70px 16px', paddingLeft: '300px', paddingRight: '300px' }} id="about">
 <h3 class="w3-center">ABOUT</h3>

 <p className="w3-center" style={{ fontSize: '14px' }}>
 At Know Your Neighborhood Village, we envision neighborhoods where residents have a strong sense of belonging and actively contribute to the betterment of their communities. We strive to create an environment where neighbors come together, learn from one another, and collaborate to make a positive impact.</p>



<div className="w3-row-padding w3-center" style={{ marginTop: '64px' }}>

    <div class="w3-quarter">
      <i class="fa fa-desktop w3-margin-bottom w3-jumbo w3-center"></i>
      <p class="w3-large">TEAMWORK</p>
      <p class="w3-medium">It focuses on encouraging residents to understand the resources available to them, and build stronger connections with their neighbors.</p> </div>
    <div class="w3-quarter">
      <i class="fa fa-heart w3-margin-bottom w3-jumbo"></i>
      <p class="w3-large">ACTIVE</p>
      <p class="w3-medium">This can include neighborhood workshops on local governance and services, community festivals, and volunteer opportunities.</p>
    </div>
    <div class="w3-quarter">
      <i class="fa fa-desktop w3-margin-bottom w3-jumbo w3-center"></i>
      <p class="w3-large">AFFORDABLE</p>
      <p class="w3-medium">Remains highly affordable, making it an excellent choice for businesses and individuals.</p>
    </div>
    <div class="w3-quarter">
      <i class="fa fa-cog w3-margin-bottom w3-jumbo"></i>
      <p class="w3-large">SUPPORT</p>
      <p class="w3-medium">Empower residents to take an active role in shaping and improving their neighborhoods. </p>
    </div>
  </div>
</div>



<img src="https://i.imgur.com/VOqZDk9.jpg" width="100%" height="auto"/>


<div className="w3-container" style={{ backgroundColor: '#222', color: 'white', padding: '80px 16px', paddingLeft: '200px', paddingRight: '200px' }}>
<div class="w3-row-padding">
    <div class="w3-col m6">
      <h3 style={{ fontSize: '30px' }}>SERVICES</h3>

      <p class="w3-medium">Know Your Neighborhood Village often collaborates with local government organizations, community centers, and neighborhood associations to implement its initiatives. 



</p>
      <p><a href="#pricing" class="w3-button w3-medium w3-green"><i class="fa fa-th">&nbsp;</i> VIEW OUR PRICES</a></p>
    </div>
    <div class="w3-col m6">
      <img class="w3-image w3-round-large" src="https://i.imgur.com/ydO6BHC.png" alt="Buildings" width="700" height="394"></img>
    </div>
  </div>
</div>









<div className="w3-container" style={{ padding: '80px 16px', paddingLeft: '200px', paddingRight: '200px' }} id="team">
  <h3 class="w3-center">THE TEAM</h3>
  <p class="w3-center w3-large">The ones who runs this company</p>
  <div className="w3-row-padding" style={{ marginTop: '64px' }}>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
      
      <img src="https://www.thenews.com.pk/assets/uploads/updates/2020-05-20/661411_095901_updates.jpg" alt="John" style={{ width: '100%', height: '120px' }} />
<div class="w3-container">
          <h3>Hairy Smiles</h3>
          <p class="w3-opacity w3-medium">CEO &amp; Founder</p>
          <p class=" w3-medium">The person who created this hosting company.</p>
          <p class="w3-medium"><button class="w3-button w3-light-grey w3-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        
        <img src="https://people.com/thmb/HASnCxTPTFT41QW422Rkr1HZWQ0=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc():focal(719x349:721x351)/zayn-malik-grammys-032423-7ed19864859f40caa61ec08458090a14.jpg" style={{ width: '100%', height: '120px' }} />
        <div class="w3-container">
          <h3>Zin Mayleek</h3>
          <p class="w3-opacity w3-medium">Art Director</p>
          <p class=" w3-medium">The head of art designs for the interface.</p>
          <p class="w3-medium"><button class="w3-button w3-light-grey w3-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        
      <img src="https://assets.teenvogue.com/photos/591b0a59a222200543173294/16:9/w_2560%2Cc_limit/GettyImages-683720714.jpg" alt="Mike" style={{ width: '100%', height: '120px' }} />

        
        <div class="w3-container">
          <h3>Layum Pained</h3>
          <p class="w3-opacity w3-medium">Web Designer</p>
          <p class=" w3-medium">The head of the website front-end department.</p>
          <p class="w3-medium"><button class="w3-button w3-light-grey w3-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
        
      <img src="https://www.goldderby.com/wp-content/uploads/2023/03/team-niall-horan-the-voice-season-23.jpg" alt="Dan" style={{ width: '100%', height: '120px' }} />

        
        <div class="w3-container">
          <h3>Niyall Horseman</h3>
            <p class="w3-opacity w3-medium">Designer</p>
          <p class=" w3-medium">The concept designer of the website.</p>
          <p class="w3-medium"><button id="pricing2" class="w3-button w3-light-grey w3-block"><i class="fa fa-envelope"></i> Contact</button></p>
        </div>
      </div>
    </div>
  </div>
</div>










<div id="pricing" className="w3-container pricing w3-medium w3-center" style={{ backgroundColor: '#222', color: 'white', padding: '70px 16px', paddingLeft: '300px', paddingRight: '300px' }}>

  <h3>PRICE</h3>
  <p class="w3-large">Choose a pricing plan that fits your needs.</p>
  <div class="w3-row-padding">
  
    <div class="w3-third w3-section">
    
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">Basic</li>
        <li class="w3-padding-10"><b>100 square meters</b></li>
        <li class="w3-padding-2"><b>Garden</b> Availablility</li>
        <li class="w3-padding-2">
          <h2 class="w3-wide">$1,000</h2>
          <span class="w3-opacity">per month</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Sign Up</button>
        </li>
      </ul>
    </div>
    <div class="w3-third">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-green w3-xlarge w3-padding-32">Pro   <a class="w3-small">(Best Value)</a></li>
        <li class="w3-padding-10"><b>300 square meters</b></li>
        <li class="w3-padding-2"><b>Parking Lot</b> Availablility</li>
        <li class="w3-padding-2"><b>Lawn Maintenance</b></li>
        <li class="w3-padding-10">
          <h2 class="w3-wide">$2,500</h2>
          <span class="w3-opacity">per month</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-green w3-padding-large">Sign Up</button>
        </li>
      </ul>
    </div>
    <div class="w3-third w3-section">
      <ul class="w3-ul w3-white w3-hover-shadow">
        <li class="w3-black w3-xlarge w3-padding-32">Premium</li>
        <li class="w3-padding-10"><b>1000 square meters</b></li>
        <li class="w3-padding-2"><b>Pool Availability</b></li>
        <li class="w3-padding-10">
          <h2 class="w3-wide">$5,000</h2>
          <span class="w3-opacity">per month</span>
        </li>
        <li class="w3-light-grey w3-padding-24">
          <button class="w3-button w3-black w3-padding-large">Sign Up</button>
        </li>
      </ul>
    </div>
  </div>
</div>







<div className="w3-container w3-light-grey w3-padding-64" style={{ paddingLeft: '200px', paddingRight: '200px' }}>




  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>OUR SKILLS</h3>
      <p class="w3-medium">We have a lot of skills in the field of living the best life for our customers.<br/>
      
    </p></div>
    <div class="w3-col m6">
      <p class="w3-wide"><i class="fa fa-desktop w3-margin-right"></i>INTERIOR DESIGN</p>
      <div class="w3-grey">


      <div className="w3-container w3-dark-grey w3-center" style={{ width: '99%' }}>99%</div>
</div>
<p className="w3-wide"><i className="fa fa-desktop w3-margin-right"></i>EXTERIOR DESIGN</p>
<div className="w3-grey">
  <div className="w3-container w3-dark-grey w3-center" style={{ width: '94%' }}>94%</div>


      </div>
      </div>
    </div>
  </div>





  <div className="w3-container w3-row w3-center w3-padding-64" style={{ backgroundColor: '#111', color: 'white' }}>

  <div class="w3-quarter">
    <span class="w3-xxlarge">10+</span>
    <br></br>Partners
  </div>
  <div class="w3-quarter">
    <span class="w3-xxlarge">200+</span>
    <br></br>Customers
  </div>
  <div class="w3-quarter">
    <span class="w3-xxlarge">300+</span>
    <br></br>Homes
  </div>
  <div class="w3-quarter">
    <span class="w3-xxlarge">250+</span>
    <br></br>Maintenance Workers
  </div>
</div>








<div className="w3-container w3-medium" style={{ backgroundColor: '#222', color: 'white', padding: '58px 16px', paddingLeft: '500px', paddingRight: '500px' }} id="contact">


   <h3 class="w3-center">CONTACT</h3>
  <p class="w3-center w3-large">Lets get in touch. Send us a message:</p>
  <div style={{ marginTop: '48px' }}>

    <form target="_blank">
      <p><input class="w3-input w3-border" type="text" placeholder="Name" required="" name="Name"></input></p>
      <p><input class="w3-input w3-border" type="text" placeholder="Email" required="" name="Email"></input></p>
      <p><input class="w3-input w3-border" type="text" placeholder="Subject" required="" name="Subject"></input></p>
      <p><input class="w3-input w3-border" type="text" placeholder="Message" required="" name="Message"></input></p>
      <p>
        <button class="w3-button w3-black" >
          <i class="fa fa-paper-plane"></i> SEND MESSAGE
        </button>
      </p>
    </form><br></br>
    <p><i class="fa fa-map-marker fa-fw w3-xxmedium w3-margin-right"></i> Cebu, Philippines</p>
    <p><i class="fa fa-phone fa-fw w3-xxmedium w3-margin-right"></i> Phone: +12 123123</p>
    <p><i class="fa fa-envelope fa-fw w3-xxmedium w3-margin-right"> </i> Email: aaawebhosting@support.com</p>
  </div>
</div>





</div>

    );
  }
}
export default About;

