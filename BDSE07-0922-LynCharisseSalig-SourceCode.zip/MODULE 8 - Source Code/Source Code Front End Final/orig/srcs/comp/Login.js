import React, { Component } from 'react';
class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isDarkMode: false,
    };
  }


  handleLoginClick = () => {
    window.location.href = "https://www.facebook.com/login.php?skip_api_login=1&api_key=817129163111098&kid_directed_site=0&app_id=817129163111098&signed_next=1&next=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D817129163111098%26redirect_uri%3Dhttp%253A%252F%252Flocalhost%253A9191%252Flogin%26response_type%3Dcode%26state%3DICUg9W%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Daae9477c-f8c0-417e-97cf-6a24fb4a6450%26tp%3Dunspecified&cancel_url=https%3A%2F%2Flocalhost%3A9191%2Flogin%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3DICUg9W%23_%3D_&display=page&locale=en_US&pl_dbl=0";
 
    this.setState({
      isDarkMode: false,
    });
  };

  toggleDarkMode = () => {
    this.setState((prevState) => ({
      isDarkMode: !prevState.isDarkMode,
    }));
  };

  render() {
    const { isDarkMode } = this.state;

    return (
      <div class="pagediv">

        <main className="main">
        <div className={`containerlogin ${isDarkMode ? 'dark-mode' : ''}`}>
            <section className="wrapper">
              <div className="heading">
                <h1 className="text text-large">Sign In</h1>
                <p className="text text-normal">
                  New user?{' '}
                  <span>
                    <a href="/Register" className="text-links">
                      Create an account
                    </a>
                  </span>
                </p>
              </div>
              <form name="signin" className="form">
                <div className="input-control">
                  <label htmlFor="email" className="input-label" hidden>
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    name="email"
                    id="email"
                    className="input-field"
                    placeholder="Email Address"
                  />
                </div>
                <div className="input-control">
                  <label htmlFor="password" className="input-label" hidden required>
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    name="password"
                    id="password"
                    className="input-field"
                    placeholder="Password"
                  />
                </div>
                <div className="input-control">
                  <a href="#" className="text-links" required>
                    Forgot Password
                  </a>
                  <input type="submit" name="submit" className="input-submit" value="Sign In" />
                </div>
              </form>
              <div className="striped">
                <span className="striped-line"></span>
                <span className="striped-text">Or</span>
                <span className="striped-line"></span>
              </div>

              <div className="method">
                <div className="method-control"><button style={{ width: '100%'}}  onClick={this.handleLoginClick}>
                  <a href="#" className="method-action">
                    <img src="https://i.imgur.com/vDIE7nV.png" alt="Facebook Logo" />
                    <span>Sign in with Facebook</span>
                  </a></button>
                </div>


                <div className="method-control">
                  <a href="#" className="method-action">
                    <img src="https://i.imgur.com/AA7tajB.png" alt="Google Logo" />
                    <span>Sign in with Google</span>
                  </a>
                </div>


              </div>
            </section>
          </div>
        </main>




        <script type="text/javascript">
          {`$.get("/user", function(data) {
            $("#user").html(data.userAuthentication.details.name);
            $(".unauthenticated").hide();
            $(".authenticated").show();
          });`}
        </script>

      </div>
    );
  }
}

export default Login;






