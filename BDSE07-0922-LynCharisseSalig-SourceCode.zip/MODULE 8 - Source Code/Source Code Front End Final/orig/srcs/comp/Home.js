import React, { Component } from 'react';

class Home extends Component {
  render() {
    return (
      <>
        <div className="pagediv">
          <link
            rel="stylesheet"  
            href="https://fonts.googleapis.com/css?family=Bebas+Neue"
          />
          <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
          />
          <div className="containerz">
            <img
              src="https://i.imgur.com/FvipXWf.jpg"
              alt="home"
              style={{ width: '100%', filter: 'brightness(40%)'}}
            />
            <div
              className="bottom-left"
              style={{ lineHeight: '60px', fontSize: '80px' }}
            >
              <a style={{ color: 'white', boxShadow: '0px 0px 5 px #000' }}>KNOW YOUR NEIGHBORHOOD</a>
              <br />
              <a style={{ color: 'white' }}>SUBDIVISION VILLAGE</a>
            </div>
          </div>

          <div
            className="w3-container"
            style={{
              backgroundColor: '#222',
              color: 'white',
              padding: '50px 16px',
              paddingLeft: '250px',
              paddingRight: '250px',
              fontSize: '20px',
              fontFamily: 'arial',
            }}
            id="about"
          >
            <h3 className="w3-center">ABOUT US</h3>

            <p className="w3-center" style={{ fontSize: '17px' }}>
 At Know Your Neighborhood Village, we envision neighborhoods where residents have a strong sense of belonging and actively contribute to the betterment of their communities. We strive to create an environment where neighbors come together, learn from one another, and collaborate to make a positive impact.</p>

          </div>

          <div
            className="w3-container"
            style={{
              backgroundColor: '#111',
              color: 'white',
              padding: '80px 16px',
              paddingLeft: '200px',
              paddingRight: '200px',
            }}
          >
            <div className="w3-row-padding" >
              <div className="w3-col m6">
                <h3 style={{ fontSize: '30px' }}>SERVICES</h3>
                <p className="w3-medium">
                  Know Your Neighborhood Village often collaborates with local
                  government organizations, community centers, and neighborhood
                  associations to implement its initiatives.
                </p>
                <p>
                  <a href="#pricing" className="w3-button w3-medium w3-green">
                    <i className="fa fa-th">&nbsp;</i> VIEW OUR PRICES
                  </a>
                </p>
              </div>
              <div className="w3-col m6">
                <img
                  className="w3-image w3-round-large"
                  src="https://i.imgur.com/ydO6BHC.png"
                  alt="Buildings"
                  width="700"
                  height="394"
                />
              </div>
            </div>
          </div>

          <div
            id="pricing"
            className="w3-container pricing w3-medium w3-center"
            style={{
              backgroundColor: '#222',
              color: 'white',
              padding: '70px 16px',
              paddingLeft: '300px',
              paddingRight: '300px',
            }}
          >
            <h3>PRICE</h3>
            <p className="w3-large">
              Choose a pricing plan that fits your needs.
            </p>
            <div className="w3-row-padding">
              <div className="w3-third w3-section">
                <ul className="w3-ul w3-white w3-hover-shadow">
                  <li className="w3-black w3-xlarge w3-padding-32">Basic</li>
                  <li className="w3-padding-10">
                    <b>100 square meters</b>
                  </li>
                  <li className="w3-padding-2">
                    <b>Garden</b> Availability
                  </li>
                  <li className="w3-padding-2">
                    <h2 className="w3-wide">$1,000</h2>
                    <span className="w3-opacity">per month</span>
                  </li>
                  <li className="w3-light-grey w3-padding-24">
                    <button className="w3-button w3-black w3-padding-large">
                    RENT NOW
                    </button>
                  </li>
                </ul>
              </div>
              <div className="w3-third">
                <ul className="w3-ul w3-white w3-hover-shadow">
                  <li className="w3-green w3-xlarge w3-padding-32">
                    Pro <a className="w3-small">(Best Value)</a>
                  </li>
                  <li className="w3-padding-10">
                    <b>300 square meters</b>
                  </li>
                  <li className="w3-padding-2">
                    <b>Parking Lot</b> Availability
                  </li>
                  <li className="w3-padding-2">
                    <b>Lawn Maintenance</b>
                  </li>
                  <li className="w3-padding-2">
                    <b>Sports Court Access</b>
                  </li>
                  <li className="w3-padding-10">
                    <h2 className="w3-wide">$2,500</h2>
                    <span className="w3-opacity">per month</span>
                  </li>
                  <li className="w3-light-grey w3-padding-24">
                    <button className="w3-button w3-green w3-padding-large">
                      RENT NOW
                    </button>
                  </li>
                </ul>
              </div>
              <div className="w3-third w3-section">
                <ul className="w3-ul w3-white w3-hover-shadow">
                  <li className="w3-black w3-xlarge w3-padding-32">
                    Premium
                  </li>
                  <li className="w3-padding-10">
                    <b>1000 square meters</b>
                  </li>
                  <li className="w3-padding-2">
                    <b>Swimming Pool</b> Availability
                  </li>
                  <li className="w3-padding-2">
                    <b>Sports and Golf </b> Access
                  </li>
                  <li className="w3-padding-10">
                    <h2 className="w3-wide">$5,000</h2>
                    <span className="w3-opacity">per month</span>
                  </li>
                  <li className="w3-light-grey w3-padding-24">
                    <button className="w3-button w3-black w3-padding-large">
                    RENT NOW
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>

        </div>
      </>
    );
  }
}

export default Home;
