import React, { Component } from 'react';
import axios from 'axios';

class Terms extends Component {

  render() {
    return (

<div class="pagediv">

<div class="termbody">
	<h1>Terms and Conditions</h1>

	<h2>1. Access to the Services</h2>
  <p> 1.1. The "Know Your Neighborhood" services are intended for residents and members of the subdivision village. </p>
  <p>1.2. You must be of legal age or have the consent of a parent or guardian to access and use our services.</p>

	<h2>2. User Conduct</h2>
  <p>
    2.1. By using our services, you agree to conduct yourself in a respectful and lawful manner.
  </p>
  <p>
    2.2. You must not engage in any activity that violates local, state, national, or international laws or regulations.
  </p>


	<h2>3. Privacy and Data Protection</h2>
 
  <p> 3.1. We respect your privacy and are committed to protecting your personal information. Our Privacy Policy explains how we collect, use, and safeguard your data.
  </p>
  <p>
    3.2. By using our services, you consent to the collection, use, and storage of your personal information as outlined in our Privacy Policy.
  </p>

	<h2>4.  Intellectual Property</h2>
  <p>
    4.1. All content and materials provided through our services, including but not limited to text, images, logos, and trademarks, are the property of "Know Your Neighborhood" or our licensors and are protected by applicable intellectual property laws.
  </p>
  <p>
    4.2. You may not reproduce, distribute, modify, transmit, or use any of our intellectual property without prior written permission from us.
</p>

	<h2>5. Disclaimer</h2>
  <p>
    5.1. The information provided through our services is for general informational purposes only. We do not guarantee the accuracy, completeness, or reliability of the information.
  </p>
  <p>
    5.2. We are not responsible for any loss or damage resulting from the use of our services or reliance on the information provided.
  </p>


	<h2>6. Indemnification</h2>
	<p>6.1. You agree to indemnify and hold us harmless from any claim or demand, including reasonable attorneys' fees, made by any third party due to or arising out of your use of our website or services, your violation of these Terms and Conditions, or your violation of any rights of another.</p>

	<h2>7. Governing Law</h2>
	<p>7.1. These Terms and Conditions shall be governed by and construed in accordance with the laws of the Philippies], without giving effect to any principles of conflicts of law.</p>

	<h2>8. Changes to Terms and Conditions</h2>
	<p>8.1. We reserve the right to change these Terms and Conditions at any time without prior notice. Your continued use of our website or services after any such changes constitutes your acceptance of the new Terms and Conditions.</p>

	<h2>9. Contact Us</h2>
	<p>9.1. If you have any questions or concerns about these Terms and Conditions, please contact us at <u>kyn@support.com</u>.</p>
</div>


</div>

    );
  }
}
export default Terms;

