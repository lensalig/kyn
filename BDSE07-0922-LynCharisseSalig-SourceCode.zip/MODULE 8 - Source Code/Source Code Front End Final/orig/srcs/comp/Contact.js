
import React, { Component, useState } from 'react';
import axios from 'axios';

class Contact extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isDarkMode: false,
    };
  }

  toggleDarkMode = () => {
    this.setState((prevState) => ({
      isDarkMode: !prevState.isDarkMode,
    }));
  };

  render() {
    const { isDarkMode } = this.state;

    return (
      <div className={`pagedivcontact ${isDarkMode ? 'dark-mode' : ''}`}>


        <div className="content">
          <div style={{ textAlign: 'center' }}>
            <h2>Contact Us</h2>
            <p>
              You can submit here or contact us via <u>support@kny.com</u>
            </p>
          </div>

          <div className="row">
            <div className="column">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1962.5208252357575!2d123.91046902554689!3d10.338552031339498!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33a998e133925eeb%3A0xfeda037a6ba9d730!2sUniversity%20of%20Cebu%20-%20Banilad%20Campus!5e0!3m2!1sen!2sph!4v1680061745787!5m2!1sen!2sph"
                width="400"
                height="450"
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>
  <div className="column">
    <form >
      <label htmlFor="name">Full Name</label>
      <input type="text" id="fname" name="firstname" placeholder="Your name.." />
      <label htmlFor="concern">Concern</label>
      <select id="concern" name="concern">
        <option value="buy">Buying a House</option>
        <option value="rent">Renting a House</option>
        <option value="flip">Flipping a House</option>
      </select>
      <label htmlFor="subject">Subject</label>
      <textarea id="subject" name="subject" placeholder="Write something.." style={{ height: '170px' }}></textarea>
      <input type="submit" value="SUBMIT" />
              </form>
            </div>
          </div>
    <p><i class="fa fa-map-marker fa-fw w3-xxmedium w3-margin-right"></i> Cebu, Philippines</p>
    <p><i class="fa fa-phone fa-fw w3-xxmedium w3-margin-right"></i> Phone: +12 123123</p>
    <p><i class="fa fa-envelope fa-fw w3-xxmedium w3-margin-right"> </i> Email: aaawebhosting@support.com</p>
        </div>

        
<div class="toggle-switch">
  <label class="switch-label">
    <input type="checkbox"  onClick={this.toggleDarkMode} class="checkbox"/>
    <span class="slider"></span>
  </label>
        </div>
      </div>
    );
  }
}

export default Contact;




