import React from 'react';
import { Link } from 'react-router-dom';

const Header = ({ loggedIn, handleLogout }) => {
  return (

    <div></div>
  );
};

export default Header;
