import $ from 'jquery';
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Login = () => {
  const [email, setEmail] = useState("");
  const [userDetail, setUserDetail] = useState({});
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("loggedIn") === "true";
    const storedEmail = localStorage.getItem("userEmail");
    setEmail(storedEmail); 
    setLoggedIn(isLoggedIn);
  }, []);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    if (name === "email") {
      setEmail(value);
    } else if (name === "password") {
      setPassword(value);
    }
  };

  const handleLogout = () => {
    localStorage.setItem("loggedIn", "false");
    localStorage.removeItem("userEmail");
    setLoggedIn(false);
    window.location.reload();
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("/user");
        console.log("Data: ");
        console.log(response.data);
        $('#user').html(response.data.userAuthentication.details.name);
        console.log('After name id: ' + response.data.userAuthentication.details.id);
        console.log('After name name: ' + response.data.userAuthentication.details.name);
        $('.unauthenticated').hide();
        $('.authenticated').show();
        setUserDetail(response.data.userAuthentication.details);
      } catch (error) {
        console.log("Error fetching user data:", error);
      }
    };

    fetchData();
  }, []);

  const redirectToFacebookLogin = () => {
    localStorage.setItem("loggedIn", "true");
    window.location.href = "http://localhost:9191/login";
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
  
    try {
      const response = await axios.post("http://localhost:9191/Login", { email, password });
      if (response.data === "Login Success") {
        console.log("Login successful");
        localStorage.setItem("loggedIn", "true");
        localStorage.setItem("userEmail", email);
        setLoggedIn(true);
  
        alert("\n✅ Logging in...");
  
        // Reload the page
        window.location.href = 'http://localhost:3000/';

      } else {
        console.log("Could not find your account.");
        setLoggedIn(false);
        alert("\n❌ Could not find your account. ❌\n");
      }
    } catch (error) {
      console.log("Login failed:", error);
      alert("❌ Could not connect to the server. ❌");
    }
  };

  return (
    <div className="pagediv">
      {loggedIn ? (
        <div className="containerloginbgonly">

{loggedIn && <script> {loggedIn && `$('.hidelog').hide(); $('.hidereg').hide();`}</script>  }



          <div className="container mt-5" style={{ paddingBottom: '120px', paddingTop: '50px' }}>
            <div className="row d-flex justify-content-center">
              <div className="col-md-7">
                <div className="card p-3 py-4" style={{ backgroundColor: '#111' }}>
                  <div className="text-center">
                    <img
                      style={{ width: '80px', justifyContent: 'center', textAlign: 'center' }}
                      src="https://img.freepik.com/free-icon/user_318-159711.jpg"
                      className="rounded-circle mx-auto d-block"
                      alt="User Profile"
                    />
                  </div>
                  <div className="text-center mt-3">
                    <span className="bg-secondary p-1 px-4 rounded text-white">
                      UI/UX DESIGNER
                    </span><br></br>
                    <h3 className="mt-2 mb-0">{userDetail.name}</h3>
                    <div className="px-4 mt-2">
                      <p className="fonts">
                        Hello, I specialize in UI/UX Designing, mostly for front end.
                        I just love making the website colorful and helping users navigate it properly.
                      </p>
                      <p>Contact: {email}</p>
                    </div>
                    <div className="buttons">
                      <br /><a href="/Home">
                        <button className="btn btn-outline-success text-white px-4">
                          <a style={{ textDecoration: 'none', color: 'white' }}>
                            HOME
                          </a>
                        </button>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <main className="main">
          <div className="containerlogin">
            <section className="wrapper">
              <div className="heading">
                <h1 className="text text-large">Sign In</h1>
                <p className="text text-normal">
                  New user?{' '}
                  <span>
                    <a href="/Register" className="text-links">
                      Create an account
                    </a>
                  </span>
                </p>
              </div>
              <form name="signin" className="form" href="/Login" onSubmit={handleSubmit}>
                <div className="input-control">
                  <label htmlFor="email" className="input-label" hidden>
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    id="email"
                    className="input-field"
                    placeholder="Email Address"
                    name="email"
                    value={email}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="input-control">
                  <label
                    htmlFor="password"
                    className="input-label"
                    hidden
                    required
                  >
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    name="password"
                    id="password"
                    className="input-field"
                    placeholder="Password"
                    value={password}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="input-control">
                  <a href="#" className="text-links">
                    Forgot Password
                  </a>
                  <input
                    type="submit"
                    name="submit"
                    className="input-submit"
                    value="Sign In"
                  />
                </div>
              </form>
              <div className="striped">
                <span className="striped-line"></span>
                <span className="striped-text">Or</span>
                <span className="striped-line"></span>
              </div>
              <div className="method">
                <div className="method-control">
                  <button style={{ width: '100%' }}  onClick={redirectToFacebookLogin}>
                    <a href="#" className="method-action">
                      <img
                        src="https://i.imgur.com/vDIE7nV.png"
                        alt="Facebook Logo"
                      />
                      <span>Sign in with Facebook</span>
                    </a>
                  </button>
                </div>
                <div className="method-control">
                  <button style={{ width: '100%' }}>
                    <a href="#" className="method-action">
                      <img
                        src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/1200px-Google_%22G%22_Logo.svg.png"
                        alt="Google Logo"
                      />
                      <span>Sign in with Google</span>
                    </a>
                  </button>
                </div>
              </div>
            </section>
          </div>
        </main>
      )}
    </div>
  );
};

export default Login;













