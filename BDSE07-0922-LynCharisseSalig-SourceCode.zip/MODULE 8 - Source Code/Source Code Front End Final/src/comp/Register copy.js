import React, { Component } from 'react';
import axios from 'axios';

class Register extends Component {
  constructor() {
    super();
    this.state = {
      email: '',
      password: '',
      name: '',
      phoneNumber: '',
    };
  }

  nameChange = (event) => {
    this.setState({
      name: event.target.value,
    });
  };

  phoneNumberChange = (event) => {
    this.setState({
      phoneNumber: event.target.value,
    });
  };

  emailChange = (event) => {
    this.setState({
      email: event.target.value,
    });
  };

  passwordChange = (event) => {
    this.setState({
      password: event.target.value,
    });
  };

  addAccount = (event) => {
    alert(
      this.state.name +
        ' ' +
        this.state.phoneNumber +
        ' ' +
        this.state.email +
        ' ' +
        this.state.password
    );
    axios
      .post('Registrations', this.state)
      .then((res) => {
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  redirectToFacebookLogin = () => {
    window.location.href = 'https://www.facebook.com/login.php?skip_api_login=1&api_key=125701013857221&kid_directed_site=0&app_id=125701013857221&signed_next=1&next=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D125701013857221%26redirect_uri%3Dhttp%253A%252F%252Flocalhost%253A8081%252Flogin%26response_type%3Dcode%26state%3DBfep95%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Dc002736e-49bb-45f2-956b-a20dfc5b41d2%26tp%3Dunspecified&cancel_url=https%3A%2F%2Flocalhost%3A8081%2Flogin%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3DBfep95%23_%3D_&display=page&locale=en_US&pl_dbl=0';
  };
  render() {
    return (

      <div>
      <div>
        <main className="main">
          <div className="containerreg">
            <section className="wrapperreg">
              <div className="heading">
                <h1 className="text text-large">Register</h1>
                <p className="text text-normal">
                  Already have an account?{' '}
                  <span>
                    <a href="/Login" className="text-links">
                      Login
                    </a>
                  </span>
                </p>
              </div>
              <form name="signin" onSubmit={this.addAccount} className="form">

              <div className="input-control">
                
              <input placeholder="Email Address" className="input-field" type="email" value={this.state.email} required
              onChange={this.emailChange}/>

                  </div>
                  <div className="input-control">
                    <label htmlFor="password" className="input-label" hidden required>
                    Password
                    </label>
                    <input
                      type="password"
                      required
                      name="password"
                      id="password"
                      className="input-field"
                      placeholder="Password"
                      value={this.state.password}
                      onChange={this.passwordChange}
                    />
                  
                  </div>

                  
              <div className="input-control">
                  <input
                    type="fullname"
                    required
                    name="fullname"
                    id="fullname"
                    className="input-field"
                    placeholder="Full Name"
                    value={this.state.fullname}
                    onChange={this.fullnameChange}
                  />
                </div>

                <div className="input-control">
                  <input
                    type="number"
                    required
                    name="number"
                    id="number"
                    className="input-field"
                    value={this.state.number}
                    onChange={this.numberChange}
                    placeholder="Contact Number"  maxlength="10" pattern="\d{10}" title="Please enter exactly 10 digits" 
                  />
                </div>


                <div className="input-controlreg">
                  <input type="submit" name="submit" className="input-submitreg" value="REGISTER" />
                </div>
              </form>
              <div className="striped">
                <span className="striped-line"></span>
                <span className="striped-text">Or</span>
                <span className="striped-line"></span>
              </div>

              <div className="method">
                <div className="method-control"><button style={{ width: '100%'}}   onClick={this.redirectToFacebookLogin}>
                  <a href="#" className="method-action">
                    <img src="https://i.imgur.com/vDIE7nV.png" alt="Facebook Logo" />
                    <span>Sign up with Facebook</span>
                  </a></button>
                </div>
                

                <div className="method-control">
                  <button style={{ width: '100%'}}>
                    <a href="#" className="method-action">
                      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Google_%22G%22_Logo.svg/1200px-Google_%22G%22_Logo.svg.png" alt="Google Logo" />
                      <span>Sign up with Google</span>
                    </a>
                  </button>
                </div>
                
              </div>
            </section>
          </div>
        </main>

      </div>


</div>

    );
  }
}
export default Register;


