import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Link, Routes, } from 'react-router-dom';

import './App.css';
import Home from './comp/Home';
import About from './comp/About';
import Contact from './comp/Contact';
import Terms from './comp/Terms';
import Register from './comp/Register';
import Login from './comp/Login';
import Header1 from './comp/Header1';
import $ from 'jquery';
import axios from 'axios';


const App = () => {
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLogout = () => {
    localStorage.setItem('loggedIn', false);
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userEmail');
    window.location.reload();
  };

    useEffect(() => {
      const isLoggedIn = localStorage.getItem('loggedIn') === 'true';
      setLoggedIn(isLoggedIn);
    }, []);


    useEffect(() => {
      if (loggedIn) {
        $('#hidelog').hide();
        $('#hidereg').hide();
        $('#showlogout').show();
      } else {
        $('#showlogout').hide();
      }
    }, [loggedIn]);

    return (




    <Router>

 
  <link rel="preconnect" href="https://fonts.gstatic.com"></link>
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&display=swap" rel="stylesheet"></link>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald"></link>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans"></link>
  
  
  
  
    <div className="fixed-top">
      <nav className="navbar navbar-expand-lg navbar-dark mx-background-top-linear">
        <div className="container">
          <a className="navbar-brand navgap" href="/Home">KNOW YOUR NEIGHBORHOOD</a>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <Link className="nav-link" to="/Home">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/About">About</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/Contact">Contact</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" id="hidelog" to="/Login">Login</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" id="hidereg" to="/Register">Register</Link>
              </li>

              <li className="nav-item">
                <Link className="nav-link" id="showlogout" to="/Login">Profile</Link>
              </li>

                    <li className="nav-item">
                    <Link className="nav-link" id="showlogout" onClick={handleLogout} style={{backgroundColor:"#8C0000", display: loggedIn ? 'block' : 'none' }}>Logout</Link>
                    </li>
      <script>
        {loggedIn && `$('#showlogout).hide();`}
      </script>
            </ul>
          </div>
        </div>
      </nav>
    </div>



    


        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"/>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"/>
  
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"/>
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0np.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"/>
        <Routes>

  <Route exact path="/">
      <Route  path="/" element={<Login />} />
      </Route>

          <Route path="/Home" element={<Home />} />
          <Route path="/About" element={<About />} />
          <Route path="/Contact" element={<Contact />} />
          <Route path="/Login" element={<Login />} />
          <Route path="/Register" element={<Register />} />
          <Route path="/Logout" element={<Login />} />
          <Route path="/Terms" element={<Terms />} />
        </Routes>

        <footer className="footers">
          <div className="container">
            <div className="row">
              <div className="col-sm-6 col-md-5">
                <h6>About</h6>
                <p className="text-justify">"Know Your Neighborhood Village aims to ensure that individuals find the perfect home that aligns with their preferences and lifestyle. With a deep understanding of the market, this business assists clients in making their life easy in each neighborhood."</p>
              </div>
              <div className="col-xs-6 col-md-2">
                <h6>Quick Links</h6>
                <ul className="footer-links">
                  <li><Link to="/Home">Homepage</Link></li>
                  <li><Link to="/About">About Us</Link></li>
                  <li><Link to="/Contact">Contact Us</Link></li>
                  <li><Link to="/Terms">Terms</Link></li>
                </ul>
              </div>
              <div className="col-xs-6 col-md-2">
                <h6>Categories</h6>
                <ul className="footer-links">
                  <li><Link to="/Login">Login</Link></li>
                  <li><Link to="/Register">Register</Link></li>
                  <li></li>
                </ul>
              </div>
              <div className="col-xs-6 col-md-3">
                <h6>CONTACT US</h6>
                <ul className="footer-links">
                  <li><a href="mailto:support@knyvillage.com">support@knyvillage.com</a></li>
                  <li><a href="tel:+639123456789">+63 912 345 6789</a></li>
                  <li><a href="#">Cebu City, Philippines</a></li>
                </ul>
              </div>
            </div>
            <hr></hr>
            <div className="text-center">
              <p className="copyright-text">
                &copy; 2023 All Rights Reserved by <a href="#">KNY Village</a>
              </p>
            </div>
          </div>

          
        </footer> 
    </Router>
  );
}

export default App;