import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import './App.css';
import Post from './comp/post';
import Cars from './comp/cars';
import Login from './comp/login';
import Message from './comp/message';
import axios from 'axios';

function App() {
  const [car, setCar] = useState([]);

  useEffect(() => {
    fetchCars();
  }, []);

  const fetchCars = () => {
    axios
      .get('/cars')
      .then((res) => {
        setCar(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <Router>
      <header className="header">
        <nav>
          <ul className="header-links">
            <li>
              <Link to="/post">Add Car</Link>
            </li>
            <li>
              <Link to="/cars">Car List</Link>
            </li>
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/message">Message</Link>
            </li>
          </ul>
        </nav>
      </header>

      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/post" element={<Post />} />
        <Route path="/message" element={<Message />} />
        <Route path="/cars" element={<Cars alldata={car} />} />
      </Routes>
    </Router>
  );
}

export default App;
