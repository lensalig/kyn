import React, { Component } from 'react';
import axios from 'axios';

class Login extends Component {

  handleLoginClick = () => {
    window.location.href = "https://www.facebook.com/login.php?skip_api_login=1&api_key=817129163111098&kid_directed_site=0&app_id=817129163111098&signed_next=1&next=https%3A%2F%2Fwww.facebook.com%2Fdialog%2Foauth%3Fclient_id%3D817129163111098%26redirect_uri%3Dhttp%253A%252F%252Flocalhost%253A9191%252Flogin%26response_type%3Dcode%26state%3DICUg9W%26ret%3Dlogin%26fbapp_pres%3D0%26logger_id%3Daae9477c-f8c0-417e-97cf-6a24fb4a6450%26tp%3Dunspecified&cancel_url=https%3A%2F%2Flocalhost%3A9191%2Flogin%3Ferror%3Daccess_denied%26error_code%3D200%26error_description%3DPermissions%2Berror%26error_reason%3Duser_denied%26state%3DICUg9W%23_%3D_&display=page&locale=en_US&pl_dbl=0";
  }

  render() {
    return (
      <div>
        <div className="container unauthenticated">
          <button className="facebook-button" onClick={this.handleLoginClick}>
            <img src="https://i.imgur.com/iqriGts.png" alt="fblogo" className="fb-logo" />
            <span className="button-text">Continue with Facebook</span>
          </button>
        </div>
        <div className="container authenticated" style={{ display: 'none' }}>
          Logged in as: <span id="user"></span>
        </div>
        <script type="text/javascript">
          {`$.get("/user", function(data) {
            $("#user").html(data.userAuthentication.details.name);
            $(".unauthenticated").hide();
            $(".authenticated").show();
          });`}
        </script>
      </div>
    );
  }
}

export default Login;
