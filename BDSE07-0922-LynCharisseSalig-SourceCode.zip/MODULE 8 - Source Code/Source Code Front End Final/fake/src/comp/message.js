import React, { Component } from "react";
import axios from "axios";

class Message extends Component {
  state = {
    username: "Abam",
    text: "",
  };

  handleInputChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };

  sendMessage = async () => {
    const { username, text } = this.state;

    if (!username || !text) {
      console.log("Please enter a username and a message");
      return;
    }

    const message = {
      text: text,
    };

    try {
      const response = await axios.post('messages/${username}',message);

      console.log("Message sent successfully:", response.data);
    } catch (error) {
      console.error("Failed to send message:", error);
    }
  };

  render() {
    const { username, text } = this.state;

    return (
      <div class="container mt-5">
        <form class="form">
            <h2>Message Here:</h2>
            <textarea name="text" value={text} onChange={this.handleInputChange} class="form-control" placeholder="Type Here"></textarea>
            <button type="button" class="btn btn-primary mt-2" onClick={this.sendMessage}>Send Message</button>       
        </form>
      </div>
    );
  }
}

export default Message;