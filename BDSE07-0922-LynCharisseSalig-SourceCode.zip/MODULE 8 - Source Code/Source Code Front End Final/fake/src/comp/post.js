import React, { Component } from 'react';
import axios from 'axios';

class Post extends Component {
  constructor(props) {
    super(props);
    this.state = {
      CarId: '',
      carName: '',
      model: '',
      make: '',
      year: ''
    };
  }

  idChange = (event) => {
    this.setState({
      CarId: event.target.value
    });
  };

  nameChange = (event) => {
    this.setState({
      carName: event.target.value
    });
  };

  modelChange = (event) => {
    this.setState({
      model: event.target.value
    });
  };

  makeChange = (event) => {
    this.setState({
      make: event.target.value
    });
  };

  yearChange = (event) => {
    this.setState({
      year: event.target.value
    });
  };

  addCar = (event) => {
    event.preventDefault();
    
    alert("Successfully saved! "+ this.state.carName+" "+this.state.model+" "+this.state.make+" "+this.state.year);
 
    axios
      .post('/cars', this.state)
      .then((res) => {
        console.log(res.data);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    return (

<div class="form-container">
  <h3>ADD YOUR CAR</h3>
  <form onSubmit={this.addCar}>
    <label for="carName">Car Name</label>
    <input
      type="text"
      id="carName"
      placeholder='Ex: Lamborghini'
      required
      value={this.state.carName}
      onChange={this.nameChange}
    />

    <label for="model">Car Model</label>
    <input
      type="text"
      id="model"
      placeholder='Ex: Aventador'
      required
      value={this.state.model}
      onChange={this.modelChange}
    />

    <label for="make">Release Year for Car</label>
    <input
      type="number"
      id="make"
      placeholder='Ex: 2017'
      required
      value={this.state.make}
      onChange={this.makeChange}
    />

    <label for="year">Price</label>
    <input
      type="number"
      id="year"
      placeholder='Input in US Dollars'
      required
      value={this.state.year}
      onChange={this.yearChange}
    />

    <button type="submit">ADD CAR</button>
  </form>
</div>

    );
  }
}
export default Post;












// try {
//   const response = await axios.get('your-url');
//   // Handle the successful response here
// } catch (error) {
//   if (error.response) {
//     // The request was made and the server responded with a status code
//     // that falls out of the range of 2xx
//     console.log(error.response.data);
//     console.log(error.response.status);
//     console.log(error.response.headers);
//   } else if (error.request) {
//     // The request was made but no response was received
//     // `error.request` is an instance of XMLHttpRequest in the browser and an instance of http.ClientRequest in node.js
//     console.log(error.request);
//   } else {
//     // Something happened in setting up the request that triggered an Error
//     console.log('Error', error.message);
//   }
//   console.log(error.config);
// }
