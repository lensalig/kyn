import React, { Component } from 'react';
import axios from 'axios';

class Cars extends Component {
  constructor(props) {
    super(props);
    this.state = {
      cars: []
    };
  }

  componentDidMount() {
    this.fetchCars();
  }

  fetchCars = () => {
    axios
      .get('/cars')
      .then((res) => {
        this.setState({
          cars: res.data
        });
      })
      .catch((error) => {
        console.log(error);
      });
  };

  render() {
    const { cars } = this.state;
    const carData = cars.map((car) => (
      <tr key={car.y
      
      }>
        <td>{car.carName}</td>
        <td>{car.model}</td>
        <td>{car.make}</td>
        <td>{car.year}</td>
      </tr>
    ));

    return (
      <div>
        <div className="container center cont">
          <h1>View All Cars</h1>
          <table className="car-table">
            <thead>mvn clean install

              <tr>
                <th>Car Name</th>
                <th>Model</th>
                <th>Year Made</th>
                <th>Price (USD)</th>
              </tr>
            </thead>
            <tbody>{carData}</tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default Cars;
