package com.KYN.service;

import org.springframework.stereotype.Service;

import com.KYN.entity.User;

@Service
public interface UserService{
	 void AddUser(User user);
	 void DeleteUser(User user);
	 User login(String email, String password);
}
