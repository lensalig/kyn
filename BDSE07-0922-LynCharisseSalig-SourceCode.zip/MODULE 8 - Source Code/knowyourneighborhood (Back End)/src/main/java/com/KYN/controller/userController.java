package com.KYN.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.KYN.entity.User;
import com.KYN.service.UserService;

@Controller
public class userController {

	@Autowired
	UserService userService;

	@PostMapping(value = "/registration")
	public String registration(@ModelAttribute("KUser") User user) {
		userService.AddUser(user);
		return "/";
	}
	
}
