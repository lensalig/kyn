package com.KYN.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.KYN.entity.User;
import com.KYN.repository.userRepo;

@Service("UserService")
public class UserImpl implements UserService {

	@Autowired
	private userRepo ur;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public void AddUser(User user) {
		String encryptedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encryptedPassword);
		ur.save(user);
		System.out.println("User added");
	}

	public void deleteUser(User user) {
		ur.delete(user);
	}

	public User login(String email, String password) {
		User user = ur.findByEmail(email);
		if (user != null && passwordEncoder.matches(password, user.getPassword())) {
			return user;
		} else {
			return null;
		}
	}

	@Override
	public void DeleteUser(User user) {
		ur.delete(user);
	}
}
