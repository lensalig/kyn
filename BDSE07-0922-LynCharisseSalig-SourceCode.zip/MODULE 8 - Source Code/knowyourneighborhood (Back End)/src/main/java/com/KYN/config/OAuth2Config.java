package com.KYN.config;

import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;



@EnableWebSecurity
@EnableOAuth2Sso
@Configuration
public class OAuth2Config extends WebSecurityConfigurerAdapter{

	@Override
	public void configure(HttpSecurity http) throws Exception {
	    http
	        .csrf().disable()
	        .authorizeRequests()
	            .antMatchers("/contact_us","/about_Us","/terms_and_condition","/Registrations", "/register","/login","/Login","/messages/{userName}", "/webjars/**", "/error**").permitAll()
	            .anyRequest().authenticated()
	        .and()
	        .logout()
	            .logoutSuccessUrl("/")
	            .permitAll()
	            .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
	            .clearAuthentication(true)
	            .invalidateHttpSession(true);
	}


}
