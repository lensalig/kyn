package com.KYN.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.KYN.entity.User;
import com.KYN.service.UserImpl;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class KYNRestController{
	
	@Autowired 
	UserImpl UserService;
	
	
	@PostMapping("/Registrations")
	public String reg(@RequestBody User u)
	{
		System.out.println(u);
		UserService.AddUser(u);
		return "User registered successfully";
	}
	
	@PostMapping("/Login")
    public String testLogin(@RequestBody User user) {
        User logUser = UserService.login(user.getEmail(), user.getPassword());
        if (logUser != null) {
            return "Login Success";
        }
        return "Login Failed";
    }
	
	
}